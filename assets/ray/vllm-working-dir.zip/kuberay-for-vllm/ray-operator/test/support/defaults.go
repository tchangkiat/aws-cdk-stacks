package support

const (
	RayVersion            = "2.41.0"
	RayImage              = "rayproject/ray:2.41.0"
	KuberayUpgradeVersion = "v1.3.0"
)
