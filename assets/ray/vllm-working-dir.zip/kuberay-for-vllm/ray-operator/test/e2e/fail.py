import sys

print("Something is seriously wrong.", file=sys.stderr)
sys.exit(1)
