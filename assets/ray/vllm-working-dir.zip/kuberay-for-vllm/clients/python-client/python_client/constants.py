# Declares the constants that are used by the client
import logging

# Group, Version, Plural
GROUP = "ray.io"
VERSION = "v1alpha1"
PLURAL = "rayclusters"
KIND = "RayCluster"

# log level
LOGLEVEL = logging.INFO
