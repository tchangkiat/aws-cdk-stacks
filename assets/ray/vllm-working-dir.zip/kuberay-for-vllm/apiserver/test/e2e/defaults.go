package e2e

const (
	RayVersion = "2.9.0"
	RayImage   = "rayproject/ray:2.9.0"
)
