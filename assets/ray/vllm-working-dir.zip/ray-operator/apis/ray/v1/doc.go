// +kubebuilder:object:generate=true
// +groupName=ray.io

package v1
